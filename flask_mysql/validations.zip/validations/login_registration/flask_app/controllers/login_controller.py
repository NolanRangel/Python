# controller
from flask import render_template, redirect, request, session, flash
from flask_app import app
from flask_app.models.login_model import Login
from flask_bcrypt import Bcrypt  

bcrypt = Bcrypt(app)




@app.route('/')
def index():
    # user = Login.user_get_all()
    return render_template('index.html',)


@app.route('/user/register', methods=['POST'])
def user_create():
    
    if not Login.validate_registration(request.form):    
        return redirect('/')
    # get email from you form data
    email = request.form["email"]
    email = {
        **request.form,
        'email': email
    }

    # check if someone already register with the email
    user = Login.get_one_by_email(email)
    print(user)
    print('*******')
    if not user:
        # the email doesnt exist
        pass
    else:
        flash('email already exists', 'err_email')
        return redirect('/')
        
        
    hash_pw = bcrypt.generate_password_hash(request.form['password'])  
    data = {
        **request.form,
        'password': hash_pw
    }  
    Login.user_create(data)
    
    session['first_name'] = request.form['first_name']
    
    return redirect('/success')


@app.route('/user/login', methods=['POST'])
def user_login():

    if not Login.validate_login(request.form):
        return redirect('/')
    
    potential_user = Login.get_one_by_email({'email': request.form['email']}) 
    
    if not potential_user or not bcrypt.check_password_hash(potential_user.password, request.form['password']):
        flash("Incorrect password", "err_login_password")
        return redirect ('/')
    
    # session['id'] = potential_user.id
    session['first_name'] = potential_user.first_name
    # print(session['first_name'])
    # print(session['id'])
    
    return redirect('/success')


@app.route('/logout')
def logout():
    del session['first_name']
    # del session['id']
    return redirect('/')



@app.route('/success', methods=['POST'])
def user_success():
    
    return render_template('success.html')



